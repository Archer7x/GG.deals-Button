// ==============================
// Utils
// ==============================
function slugify(str) {
  return str
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

// ==============================
// Page Detection
// ==============================
const isGGDeals = () => location.hostname.includes('gg.deals');
const isSteamStore = () => location.hostname === 'store.steampowered.com';
const isSteamDB = () => location.hostname.includes('steamdb.info');

// ==============================
// GG.DEALS
// ==============================
const ggDeals = {
  selectors: {
    steamLink: 'a[href*="store.steampowered.com/app/"]',
  },

  init() {
    this.addSteamDBButton();
  },

  addSteamDBButton() {
    if (document.getElementById('steamdb-button')) return;

    const steamLink = document.querySelector(this.selectors.steamLink);
    if (!steamLink) return;

    const match = steamLink.href.match(/app\/(\d+)/);
    if (!match) return;

    const appId = match[1];

    const btn = steamLink.cloneNode(true);
    btn.id = 'steamdb-button';
    btn.href = `https://steamdb.info/app/${appId}/`;
    btn.target = '_blank';
    btn.rel = 'noopener';
    btn.textContent = 'View on SteamDB';

    steamLink.after(btn);
  }
};

// ==============================
// STEAM STORE
// ==============================
const steamStore = {
  selectors: {
    title:
      '#appHubAppName, .apphub_AppName, h1',
    buttonContainer:
      '.apphub_OtherSiteInfo',
  },

  init() {
    this.addGGDealsButton();
  },

  getGameTitle() {
    return document.querySelector(this.selectors.title)?.textContent.trim();
  },

  addGGDealsButton() {
    if (document.getElementById('gg-deals-button')) return;

    const title = this.getGameTitle();
    if (!title) return;

    const container = document.querySelector(this.selectors.buttonContainer);
    if (!container) return;

    const btn = document.createElement('a');
    btn.id = 'gg-deals-button';
    btn.className = 'btnv6_blue_hoverfade btn_medium';
    btn.innerHTML = '<span>GG.deals</span>';
    btn.title = `Suche "${title}" auf GG.deals`;
    btn.href = `https://gg.deals/game/${slugify(title)}`;
    btn.target = '_blank';

    container.appendChild(btn);
  }
};

// ==============================
// STEAMDB
// ==============================
const steamDB = {
  selectors: {
    storeButton:
      'a[href*="store.steampowered.com"]',
  },

  init() {
    this.addGGDealsButton();
  },

  getGameTitle() {
    return document.querySelector('h1')?.textContent.trim();
  },

  addGGDealsButton() {
    if (document.getElementById('gg-deals-button')) return;

    const title = this.getGameTitle();
    if (!title) return;

    const storeBtn = document.querySelector(this.selectors.storeButton);
    if (!storeBtn) return;

    const btn = document.createElement('a');
    btn.id = 'gg-deals-button';
    btn.className = storeBtn.className;
    btn.textContent = 'GG.deals';
    btn.href = `https://gg.deals/game/${slugify(title)}`;
    btn.target = '_blank';

    storeBtn.after(btn);
  }
};
<y
// ==============================
// INIT
// ==============================
function init() {
  if (isGGDeals()) ggDeals.init();
  if (isSteamStore()) steamStore.init();
  if (isSteamDB()) steamDB.init();
}

// Dynamic pages support
init();
document.addEventListener('DOMContentLoaded', init);
window.addEventListener('load', init);
setTimeout(init, 500);
setTimeout(init, 1500);

// Slugify-Funktion für URLs
function slugify(str) {
  return str
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // remove accents
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

// Extrahiere den Spieltitel aus der Seite
function getGameTitle() {
  return (
    document.getElementById("appHubAppName")?.textContent.trim() ||
    document.querySelector(".apphub_AppName")?.textContent.trim() ||
    document.querySelector("h1")?.textContent.trim() ||
    null
  );
}

// Erstelle einen Button und füge ihn zur Seite hinzu
function addGGDealsButton() {
  if (location.hostname.includes('gg.deals')) addSteamdbButton();

  if (document.getElementById("gg-deals-button")) {
    return;
  }

  const gameTitle = getGameTitle();
  if (!gameTitle) {
    return;
  }

  const isStoresteampowered =
    window.location.hostname === "store.steampowered.com";

  // Erstelle einen Link
  const button = document.createElement("a");
  button.id = "gg-deals-button";
  button.href = "#";

  if (isStoresteampowered) {
    button.className = "btnv6_blue_hoverfade btn_medium";
    button.innerHTML = "<span>GG.deals</span>";
  } else {
    button.className = "btn";
    button.textContent = "GG.deals";
  }

  button.title = `Suche "${gameTitle}" auf GG.deals`;

  // Klick-Event
  button.addEventListener("click", function (e) {
    e.preventDefault();
    const ggDealsUrl = `https://gg.deals/game/${slugify(gameTitle)}`; // Direkt die game seite öffnen `https://gg.deals/search/?title=${encodeURIComponent(gameTitle)}`;
    window.open(ggDealsUrl, "_blank");
  });

  if (isStoresteampowered) {
    // Auf Steam Store: VOR dem Community Hub Button einfügen
    const container = document.querySelector(".apphub_OtherSiteInfo");
    const buttons = container?.querySelectorAll("a");

    // Suche nach Community Hub Button
    let communityButton = null;
    if (buttons) {
      for (let btn of buttons) {
        if (btn.textContent.includes("Community")) {
          communityButton = btn;
          break;
        }
      }
    }

    if (communityButton) {
      communityButton.before(button);
      // Füge einen Text-Node mit Leerraum ein, wie bei den SteamDB Buttons
      communityButton.before(document.createTextNode(" "));
    } else if (container) {
      // Fallback: In Container einfügen
      container.appendChild(button);
    }
  } else {
    // Auf SteamDB: Nach Store-Button einfügen
    const storeButtons = Array.from(
      document.querySelectorAll('a[href*="store.steampowered.com"]'),
    );
    const storeButton =
      storeButtons.find((btn) => btn.querySelector("svg.octicon-steam")) ||
      storeButtons[storeButtons.length - 1];

    if (storeButton) {
      storeButton.after(button);
    }
  }
}

function addSteamdbButton() {
    // 1. Steam-Link finden
  const steamLink = document.querySelector('a.score-grade');
  if (!steamLink) return;

  // 2. App-ID extrahieren
  const match = steamLink.href.match(/app\/(\d+)/);
  if (!match) return;

  const appId = match[1];

  // 3. SteamDB-URL
  const steamDbUrl = `https://steamdb.info/app/${appId}/`;

  // 4. Button klonen (Style bleibt gleich)
  const steamDbBtn = steamLink.cloneNode(true);
  steamDbBtn.href = steamDbUrl;
  steamDbBtn.target = '_blank';
  steamDbBtn.rel = 'nofollow noopener external';

  // Text anpassen
  const label = steamDbBtn.querySelector('.reviews-label');
  if (label) {
    label.textContent = 'View on SteamDB';
  } else {
    steamDbBtn.textContent = 'View on SteamDB';
  }

  // 5. Neben den Steam-Button einfügen
  steamLink.after(steamDbBtn);
}

function addSteamdbButton2() {
  const steamurl = document.querySelector('.score-grade').href;
  const appId = steamurl.split('/app/')[1].replace('/', '');
  
  if (document.getElementById("steamdb-button")) {
    return;
  }
}

// Mehrmals versuchen
addGGDealsButton();
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", addGGDealsButton);
}
window.addEventListener("load", addGGDealsButton);
setTimeout(addGGDealsButton, 500);
setTimeout(addGGDealsButton, 1500);

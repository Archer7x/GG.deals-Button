# GG.deals-Button
Adds a button to SteamDB and Steam Store pages to search for games on GG.deals.

(This Add-on is not affiliated with GG.deals, SteamDB or Steam by VALVE)

# Screenshots
![Screenshot of Steam store with SteamDB Add-on enabled.](https://github.com/Archer7x/GG.deals-Button/blob/main/screenshots/Screenshot%202026-02-01%20at%2020-43-11%20Half-Life%202%20on%20Steam.png)

![Screenshot of Steam store without SteamDB Add-on.](https://github.com/Archer7x/GG.deals-Button/blob/main/screenshots/Screenshot%202026-02-01%20at%2020-44-38%20Half-Life%202%20on%20Steam.png)

![Screenshot of SteamDB.](https://github.com/Archer7x/GG.deals-Button/blob/main/screenshots/Screenshot%202026-02-01%20at%2020-43-47%20Half-Life%202%20Price%20history%20%C2%B7%20SteamDB.png)
